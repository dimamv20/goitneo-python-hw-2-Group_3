from collections import UserDict


class Field:
    def __init__(self, value):
        self.value = value

    def __str__(self):
        return str(self.value)


class Name(Field):
    pass


class Phone(Field):
    def __init__(self, value):
        super().__init__(value)
        if not value.isdigit() or len(value) != 10:
            raise ValueError('Phone must be a 10-digit number')

    def __str__(self):
        return f"Phone: {self.value}"


class Record:
    def __init__(self, name):
        self.name = Name(name)
        self.phones = []

    def add_phone(self, phone_num):
        phone = Phone(phone_num)
        self.phones.append(phone)

    def remove_phone(self, phone_num):
        self.phones = [phone for phone in self.phones if phone.value != phone_num]

    def reset_phone(self, old_phone, new_phone):
        for phone in self.phones:
            if phone.value == old_phone:
                phone.value = new_phone

    def find_phone(self, phone):
        for num in self.phones:
            if num.value == phone:
                return num

    def __str__(self):
        return f"Contact name: {self.name}, phones: {', '.join(str(phone) for phone in self.phones)}"


class AddressBook(UserDict):
    def add_record(self, record):
        self.data[record.name.value] = record

    def find(self, name):
        return self.data.get(name)

    def delete(self, name):
        if name in self.data:
            del self.data[name]
        else:
            raise KeyError(f'The contact with the name "{name}" was not found.')

    def __str__(self):
        return "\n".join(str(record) for record in self.data.values())

book = AddressBook()


john_record = Record("John")
john_record.add_phone("1234567890")
john_record.add_phone("5555555555")
book.add_record(john_record)


jane_record = Record("Jane")
jane_record.add_phone("9876543210")
book.add_record(jane_record)


print(book)


john = book.find("John")
john.reset_phone("1234567890", "1112223333")
print(john)  

found_phone = john.find_phone("5555555555")
print(f"{john.name}: {found_phone}")


book.delete("Jane")
print(book)
