from menu import MENU
from sys import exit

contacts = {
    'John': '780112333212',
    'Dima': '097651233321',
    'Jane': '312441231223',
    'Kolia': '31231234412',
    'Abraham': '441231231231',
    'Oleg': '13312344123'
}

def input_error(func):
    def inner(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except ValueError:
            return "Give me name and phone please."
        except IndexError: 
            print('Invalid command format.')
        except KeyError:
            print('Contact not found.')

    return inner

@input_error
def new_phone(nick,numbers):
    contacts[nick] = numbers
    print(f'We add new contact to your list -- name: {nick} with phone:{numbers}')
    
@input_error
def update_phone(name,phone):
    if name in contacts.keys():
        contacts[name] = phone
        print(f'Contact {name} updated number: {phone}')
    else:
        print("We hadn't find any contact with this nickname")
@input_error
def show_phone(name):
    values_num = contacts[name]
    if name in contacts:

        print(f'I found {name} with this phone number: {values_num}')
@input_error
def show_all():
    print('|{:^15}|{:^15}|'.format('nickname','phone_numbers'))
    for n,p in contacts.items():
        print('|{:^15}|{:^15}|'.format(n,p))


def menu():
    
    print(MENU)


def close():

    exit()

print("Welcome to the assistant bot!")
while True:
    try:    
        command = input('Enter a command:')
        parts = command.split()
        operation = parts[0]
        
        if operation == 'add' and len(parts) == 3:
            name = parts[1]
            phone = parts[2]

            new_phone(name,phone)

        elif operation == 'change' and len(parts) == 3:
            name = parts[1]
            phone = parts[2]

            update_phone(name,phone)

        elif  operation == 'phone' and len(parts) == 2:
            n = parts[1]
            show_phone(n)
        elif operation == 'all' and len(parts) == 1:
            show_all()

        elif operation == 'menu' and len(parts) == 1:
            menu()

        elif command.lower() == 'hello' and len(parts) == 1:
            print('How I can help you?')

        elif operation in ['close', 'exit'] and len(parts) == 1:
            print('Good bye!!')
            break
    except: 
        print('Invalid command.')
